

<!DOCTYPE html>
<html>
    <head>
	<!--Author(s): Floyd / Integration to Website: Keelan -->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 
<link rel="stylesheet" type="text/css" href="css/car.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <meta charset="utf-8">
        <title>Payment</title>
        <link rel="stylesheet" href="styles.css">
    </head>
	
    <body>
	
	<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
	  <a href="#"><img src="images/logo.png" alt="logo" style="width:85px;height:42px;padding-top: 7px;padding-right: 10px;"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Models</a></li>
        <li><a href="orders.php">Orders</a></li>
 
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php"><span class="glyphicon glyphicon-user"></span> Log Out</a></li>
        <li><a href="mycart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>
	
        <div>
            <div class="container">
                <div class="payment-box">

                    <section class="row options no-border-bottom">
                        <div class="item">
                            <label class="label">
                                <span>Debit/credit card</span>
                            </label>
                        </div>
                        <div class="item">
                            <img class="img" src="images/visa.png" alt="" />
                            <img class="img" src="images/master_card.png" alt="" />
                            <img class="img" src="images/jcb_card.png" alt="" />
                        </div>
                    </section>
					<form action="payment.php" method="POST">
                    <section class="row blanks">
					<div class="col">
                            <div class="item">
                                <span class="title">Card Name</span>
                                <input class="blank" name = "cName" placeholder="Card Name" maxlength=30 required />
                            </div>
                        </div>
                        <div class="col">
                            <div class="item">
                                <span class="title">Card number</span>
                                <input class="blank card-number" name = "cardNo" placeholder="0000 0000 0000 0000" onFocus="this.value = ''" onBlur="if (this.value === '') { this.value = '0000 0000 0000 0000' }" onkeyup="if (this.value.length === 4 || this.value.length === 4 * 2 + 1 || this.value.length === 4 * 3 + 2) { this.value += ' ' }" onafterpaste="this.value=this.value.replace(/\D/g,'')" maxlength=19 required />
                            </div>
                        </div>
                    </section>
                    <section class="row blanks last">
                        <div class="col">
                            <div class="item">
                                <span class="title">Expiry</span>
                                <input class="blank" name = "expiry" placeholder="MM/YY" onkeyup="if (this.value.length === 2) { this.value += '/' }" onafterpaste="this.value=this.value.replace(/\D/g,'')" maxlength=5 required />
                            </div>
                        </div>
                        <div class="col">
                            <div class="item">
                                <span class="title">CVC</span>
                                <input class="blank" name = "CVC" placeholder="***" onkeyup="this.value=this.value.replace(/\D/g,'')" onafterpaste="this.value=this.value.replace(/\D/g,'')" maxlength=3 required />
                            </div>
                        </div>
                        <img class="info-icon" src="images/info.png" alt="" />
                    </section>
                </div>
                <button class="payment-btn" type="submit"><img src="images/lock.png" alt="" /><a href="put your confirmation code here"><b>FINISH AND PAY</b></a></button>
				</form>
<!-- menu -->
<head>
  <meta name="viewport" content="width=device-width">
</head>
<div class="wrap" style="margin-top:-3px">
<span class="decor"></span>
<nav>
  <ul class="primary">
 <li>
      <a href="mycart.php"><b>BACK</b></a>
    </li>
  </ul>
</nav>
</div>
<div class="background">
<center><img src="images/bgz.png" width=38%></center>
</div>
            </div>
        </div>
    </body>
</html>