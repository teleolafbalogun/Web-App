<?php
include 'manage_cart.php';
?>


<!DOCTYPE html>
<html lang ="en">

<head>
<!--Author(s): Canice / Integration to Website: Keelan -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 
<link rel="stylesheet" type="text/css" href="css/main.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<meta charset = "UTF-8">
<meta name ="viewport" content ="width=device-width, initial-scale =1.0">
<title>Cart</title>
</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
	  <a href="#"><img src="images/logo.png" alt="logo" style="width:85px;height:42px;padding-top: 7px;padding-right: 10px;"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Models</a></li>
        <li><a href="orders.php">Orders</a></li>
 
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="logout.php"><span class="glyphicon glyphicon-user"></span> Log Out</a></li>
        <li><a href="mycart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>


<div class="container">
    <div class="row">
      <div class="col-lg-12 text-center border rounded rounded bg-light my-5">
        <h1>Purchase Model</h1>
      </div>

      <div class="col-lg-8">
        <table class="table">
          <thead class="text-center">
            <tr>
              <th scope="col">Model</th>
              <th scope="col">Price</th>
              <th scope="col"></th>
            </tr>
          </thead>
          <tbody class="text-center">

            <?php
            if (isset($_SESSION['cart'])) {
              foreach ($_SESSION['cart'] as $key => $value) {
                $sr = $key + 1;
                echo "
                <tr>
                  <td>$value[Item_Name]</td>
                  <td>$value[Price]<input type ='hidden' class='iprice' value='$value[Price]'></td>
                  <td>
                  <form action='manage_cart.php' method='POST'>
                  <input type = 'hidden' name 'Item_Name' value = '$value[Item_Name]'>
                  </form>
                  </td>
                  <td>
                    <form action='manage_cart.php' method='POST'>
                      <button name='Remove_Item' class='btn btn-sm btn-outline-danger'>Remove</button>
                      <input type='hidden' name='Item_Name' value='$value[Item_Name]'>
                    </form>
                  </td>
                </tr>
              ";
              }
            }
            ?>
          </tbody>
        </table>
      </div>

      <div class="col-lg-3">
        <div class="border bg-light rounded p-4">
          <h5 class="text-right" id="gtotal"></h5>
          <br>


         <?php       
         
           if(isset($_SESSION['cart']) && count($_SESSION['cart']) >0)
         
            {
         
         ?>




          <form action  ="paymentpage.php" method =  "POST">


		<br>
		<button class = "btn btn-primary btn-block">Proceed to Checkout</button>
		</form>


<?php

            }


?>




</div>

</div>

  
</div>
</div>









</body>
</html>