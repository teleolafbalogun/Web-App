<?php
  $mysqlconn=mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");
    if (mysqli_connect_errno())
    {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    } else {
        $sql = "SELECT * FROM car, review";
        $res = mysqli_query($mysqlconn, $sql);
        $num_messages = mysqli_num_rows($res);
		$row = mysqli_fetch_assoc($res);
    }

?>
<html>
<head>
<!--Author(s): Keelan / Integration to Website: Keelan -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
 
<link rel="stylesheet" type="text/css" href="css/car.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<title>Cars</title
</head>
<body>


<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
	  <a href="#"><img src="images/logo.png" alt="logo" style="width:85px;height:42px;padding-top: 7px;padding-right: 10px;"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="index.php">Models</a></li>
        <li><a href="orders.php">Orders</a></li>
 
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="login.php"><span class="glyphicon glyphicon-user"></span> Log In</a></li>
        <li><a href="mycart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>

<div class="jumbotron">
  <div class="container text-center">
    <h1>Bentley Range</h1>      
    <p>Browse Our Most Recent Selection</p>
  </div>
</div>

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-primary">
        <!--<div class="panel-heading cars"><?php echo $model = $row['CarModel'] ?></div>-->
		<div class="panel-heading cars">Bentayga Azure</div>
        <div class="panel-body cars"><a href="carPages/bentaygaAzure.php"><img src="images/bentaygaAzure.png" alt="Azure" style="width:255px;height:144px" class="car-image"></a></div>
        <div class="panel-footer">Buy 50 mobiles and get a gift card</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading cars">Flying Spur</div>
        <div class="panel-body cars"><a href="carPages/flyingSpur.php"><img src="images/flyingSpur.png" alt="Spur" style="width:255px;height:144px" class="car-image"></a></div>
        <div class="panel-footer">Buy 50 mobiles and get a gift card</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading cars">Continental GT</div>
        <div class="panel-body cars"><a href="carPages/continentalGT.php"><img src="images/continentalGT.png" alt="GT" style="width:255px;height:144px" class="car-image"></a></div>
        <div class="panel-footer">Buy 50 mobiles and get a gift card</div>
      </div>
    </div>
  </div>
</div><br>

<div class="container">    
  <div class="row">
    <div class="col-sm-4">
      <div class="panel panel-danger">
        <div class="panel-heading cars">Continental GTC</div>
		
        <div class="panel-body cars"><a href="carPages/continentalGTC.php"><img src="images/continentalGTC.png" alt="GTC" style="width:255px;height:144px" class="car-image"></a></div>
		
        <div class="panel-footer">Buy 50 mobiles and get a gift card</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading cars">New Bentayga</div>
        <div class="panel-body cars"><a href="carPages/newBentayga.php"><img src="images/newBentayga.png" alt="newBentayga" style="width:255px;height:144px" class="car-image"></a></div>
        <div class="panel-footer">Buy 50 mobiles and get a gift card</div>
      </div>
    </div>
    <div class="col-sm-4"> 
      <div class="panel panel-danger">
        <div class="panel-heading cars">Bentayga</div>
        <div class="panel-body cars"><a href="carPages/bentayga.php"><img src="images/bentaygaOG.png" alt="Bentayga" style="width:255px;height:144px" class="car-image"></a></div>
        <div class="panel-footer">Buy 50 mobiles and get a gift card</div>
      </div>
    </div>
  </div>
</div><br><br>




	

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-
q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
crossorigin="anonymous"></script>
<script
src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
integrity="sha384-
ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
crossorigin="anonymous"></script>
<script src="javascript/main.js"></script>

</body>
</html>