<?php

$sName = "car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com";
$uName = "Group8";
$pass = "WebApps123!";
$db_name = "cardealership_web";

try {
	$conn = new PDO("mysql:host=$sName;dbname=$db_name",$uName, $pass);
	$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
echo "Connection failed : ". $e->getMessage();
}

?>