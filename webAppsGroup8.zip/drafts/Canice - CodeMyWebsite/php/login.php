<?php 
session_start();

if(isset($_POST['uname']) && 
   isset($_POST['pass'])){

   
    
    if(empty($_POST['uname'])){
    	echo "User name is required";
    }else if(empty($_POST['pass'])){
    	echo "Password is required";
    }else {
		$uname = $_POST['uname'];
		$pass = $_POST['pass'];
		$mysqli = mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");
		$sql = "SELECT * FROM user WHERE username = '$uname' && password = '$pass'";
        $res = mysqli_query($mysqli, $sql);
		
		$row = mysqli_fetch_assoc($res);

          $username =  $row['username'];
          $password =  $row['password'];
		  $customerID =  $row['CustomerID'];
  
          if($username == $uname){
             if($pass == $password){
                 $_SESSION['customerID'] = $customerID;
					echo "<script>
					alert('Logged In');
					window.location.href = '../index.php';
					</script>";
            
             }else {
               echo "Incorect User name or password";
			 }

          }else {
            echo "Incorect User name or password";
		  }
     
    }
}else {
	exit;
}

?>