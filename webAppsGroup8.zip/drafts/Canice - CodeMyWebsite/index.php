<?php 
include("header.php");

 ?> 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>index</title>
</head>
<body>
    
	
 
<div class = "container mt-5">
   <div class = "row">
   
   
     <div class = "col-lg-3">

      <form action ="manage_cart.php" method = "POST">
        <div class="card" >
           <img src="images/American.jpg" class="card-img-top" >
               <div class="card-body text-center">
               <h5 class="card-title">Car 1</h5>
              <p class="card-text">Price: £14000.00</p>
              <button type = "submit" name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
              <input type = "hidden" name = "Item_Name" value = "Car 1">
              <input type = "hidden" name = "Price" value = "14000">
           </div>
         </div>
      </form>

     </div>

     <div class = "col-lg-3">

      <form action ="manage_cart.php" method = "POST" >
        <div class="card" >
           <img src="images/ToyotaRed.jpg" class="card-img-top" >
               <div class="card-body text-center">
               <h5 class="card-title">Car 2</h5>
              <p class="card-text">Price: £16000.00</p>
              <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
              <input type = "hidden" name = "Item_Name" value = "Car 2">
              <input type = "hidden" name = "Price" value = "16000">
           </div>
         </div>
      </form>

     </div>


    
<div class = "col-lg-3">

<form action ="manage_cart.php"  method = "POST">
  <div class="card" >
     <img src="images/GT6-Mk3.jpg" class="card-img-top" >
         <div class="card-body text-center">
         <h5 class="card-title">Car 3</h5>
        <p class="card-text">Price: £9000.00</p>
        <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
        <input type = "hidden" name = "Item_Name" value = "Car 3">
        <input type = "hidden" name = "Price" value = "9000">
     </div>
   </div>
</form>

</div>




<div class = "col-lg-3">

<form action ="manage_cart.php" method = "POST" >
  <div class="card" >
     <img src="images/McLaren.jpg" class="card-img-top" >
         <div class="card-body text-center">
         <h5 class="card-title">Car 4</h5>
        <p class="card-text">Price: £33000.00</p>
        <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
        <input type = "hidden" name = "Item_Name" value = "Car 4">
        <input type = "hidden" name = "Price" value = "33000">
     </div>
   </div>
</form>

</div>


<div class = "col-lg-3">

<form action ="manage_cart.php" method = "POST" >
  <div class="card" >
     <img src="images/Porsche911.jpg" class="card-img-top" >
         <div class="card-body text-center">
         <h5 class="card-title">Car 5</h5>
        <p class="card-text">Price: £44000.00</p>
        <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
        <input type = "hidden" name = "Item_Name" value = "Car 5">
        <input type = "hidden" name = "Price" value = "44000">
     </div>
   </div>
</form>

</div>




<div class = "col-lg-3">

<form action ="manage_cart.php" method = "POST" >
  <div class="card" >
     <img src="images/Mustang.jpeg" class="card-img-top" >
         <div class="card-body text-center">
         <h5 class="card-title">Car 6</h5>
        <p class="card-text">Price: £50000.00</p>
        <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
        <input type = "hidden" name = "Item_Name" value = "Car 5">
        <input type = "hidden" name = "Price" value = "50000">
     </div>
   </div>
</form>

</div>


<div class = "col-lg-3">

<form action ="manage_cart.php" method = "POST" >
  <div class="card" >
     <img src="images/Camaro.jpg" class="card-img-top" >
         <div class="card-body text-center">
         <h5 class="card-title">Car 6</h5>
        <p class="card-text">Price: £50000.00</p>
        <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
        <input type = "hidden" name = "Item_Name" value = "Car 5">
        <input type = "hidden" name = "Price" value = "50000.00">
     </div>
   </div>
</form>

</div>





<div class = "col-lg-3">

<form action ="manage_cart.php" method = "POST" >
  <div class="card" >
     <img src="images/Bugatti.jpg" class="card-img-top" >
         <div class="card-body text-center">
         <h5 class="card-title">Car 7</h5>
        <p class="card-text">Price: £40000.00</p>
        <button type = "submit"name = "Add_To_Cart" class="btn btn-info">Add to Cart</button>
        <input type = "hidden" name = "Item_Name" value = "Car 6">
        <input type = "hidden" name = "Price" value = "180000.00">
     </div>
   </div>
</form>

</div>








    </div>
</div>



</body>
</html>