<?php

$mysqli = mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");

if(mysqli_connect_errno()) {
	printf("Connect failed: %s\n",mysqli_connect_error());
	exit();
} else {
	$sql = "INSERT INTO payment('CardName','CardNumber','ExpiryDate','SecurityCode','CustomerID')VALUES('".$_POST["cName"]."','".$_POST["cardNo"]."','".$_POST["expiry"]."','".$_POST["CVC"]."','".$_COOKIE['customerID']."')";
	$res = mysqli_query($mysqli,$sql);
	if($res === TRUE) {
		<script>
         alert('Payment Successful');
        window.location.href='orderPlaced.php';
        </script>";
	} else {
		printf("Could not insert record: %s\n",mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
}
?>


