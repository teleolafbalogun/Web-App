<!DOCTYPE html>
<html>
  <head><meta charset="utf-8">
    <meta name="author" content="Floyd Teleola Balogun">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Product Details</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet"href="https://use.fontawesome.com/releases/v5.7.0/css/all.css" integrity="
    sha384-lZN37f5QGtY3VHgisS14W3ExzMWZxybE1SJSEsQp9S+oqd12jhcu+A56Ebc1zFSJ" crossorigin="anonymous">
    <style>
      /* Styles for the product details */
      .product {
        display: flex;
        flex-direction: row;
        justify-content: space-between;
        align-items: center;
        border: 1px solid #ddd;
        padding: 125px;
        margin-bottom: 10px;
      }
      .product img {
        max-width: 10000px;
        max-height: 10000px;
        margin-right: 500px;
      }
      .product h2 {
        margin: 0;
      }
      .product p {
        margin: 0;
        font-size: 24px;
        color: #666;
      }
      .product .price {
        font-weight: bold;
        font-size: 18px;
      }
    </style>
  </head>
  <body>
  <nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <!-- Brand -->
  <a class="navbar-brand" href="index.php"><i class="fas fa-car"></i>&nbsp; Bentley</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav ml-auto">
      <li class="nav-item">
        <a class="nav-link active" href="index.php">Products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">Catergories</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="checkout.php">Checkout</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="cart.php"><i class="fas fa-shopping-cart"></i> <span id="cart-item" class="badge badge-danger">1</span></a>
      </li>
    </ul>
  </div>
</nav>
    <!-- Product details section -->
    <div class="product">
      <img src="images/bentaygaAzure.png" alt="Product Image">
      <div class="details">
        <h2>Bentley Bentayga Azure</h2>
        <p>Number of doors: 5</p>
<p>Acceleration 0-62 mph: 4.5 seconds</p>
<p>Cargo volume: 484 L, 1,774 L with seat area</p>
<p>Engine cylinder configuration: V engine</p>
<p>Dimensions: 5,125 mm L x 2,010 mm W x 1,728 mm H</p>
<p>Driveline: Four-wheel drive</p>
<p>Engine: 4.0 L V8.</p>
        <p>Color: Navy Blue</p>
        <BR>
        <p class="price">Price: $263,500</p>
      </div>

    
    </div>
    <div class="row-lg-2 d-flex justify-content-center">
    <form action="managecart.php" method="POST">
      <button type="submit" name="Add_To_Cart" class="btn btn-info">Add to cart</button>
      <input type="hidden" name="Item_Name" value="Car 1">
      <input type="hidden" name="Price" value="263,500">
    </form>
</div>


    
  </body>
</html>
