<?php

$mysqli=mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");


    if (mysqli_connect_errno())
    {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    } else {
        $sql = "SELECT * from car WHERE CarModel = 'Continental GTC'";
		$res = mysqli_query($mysqli,$sql);
		$row = mysqli_fetch_assoc( $res);
		
		$year = $row['CarYear'];
		$price = $row['CarPrice'];
		
    }
	

?>





<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="author" content="Floyd Teleola Balogun">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Continetal GTC</title>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/car.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
    /* Styles for the product details */
    .product {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      border: 1px solid #ddd;
      padding: 125px;
      margin-bottom: 10px;
    }

    .product img {
      max-width: 10000px;
      max-height: 10000px;
      margin-right: 500px;
    }

    .product h2 {
      margin: 0;
    }

    .product p {
      margin: 0;
      font-size: 24px;
      color: #666;
    }

    .product .price {
      font-weight: bold;
      font-size: 18px;
    }
	.btn {
	  width: 20%;
	  height: 8%;
	  
	}
  </style>
</head>

<body>
  <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
      <a class="navbar-brand" href="#">Logo</a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#">Products</a></li>
        <li><a href="#">Deals</a></li>
        <li><a href="#">Stores</a></li>
        <li><a href="#">Contact</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><span class="glyphicon glyphicon-user"></span> Your Account</a></li>
        <li><a href="#"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>
  <!-- Product details section -->
  
  <div class="product container-fluid">
    <img src="images/continentalGTC.png" alt="Product Image" style="width:auto;height:auto;" >
    <div class="details">
      <h2>Continetal GTC</h2>
	  <p>Year: <?php echo $year; ?></p>
      <p>Number of doors: 5</p>
      <p>Acceleration 0-62 mph: 4.5 seconds</p>
      <p>Cargo volume: 484 L, 1,774 L with seat area</p>
      <p>Engine cylinder configuration: V engine</p>
      <p>Dimensions: 5,125 mm L x 2,010 mm W x 1,728 mm H</p>
      <p>Driveline: Four-wheel drive</p>
      <p>Engine: 4.0 L V8.</p>
      <p>Color: Navy Blue</p>
      <BR>
      <p class="price">Price: $192400</p>
    </div>
	<div class="row-lg-2 d-flex justify-content-center">
    <form action="managecart.php" method="POST">
      <button type="submit" name="Add_To_Cart" class="btn btn-info">Add to cart</button>
      <input type="hidden" name="Item_Name" value="Car 1">
      <input type="hidden" name="Price" value="263,500">
    </form>
	</div>
  </div>

  
<h3>Reviews</h3>
  <?php
        $sql = "SELECT * FROM review WHERE CarID = 4";
        $res = mysqli_query($mysqli, $sql);
        $num_messages = mysqli_num_rows( $res);
?>

<?php
	while( $row = mysqli_fetch_assoc( $res) ) {
	 $stars = $row['Stars'];
     $commentHead = $row['CommentHead'];
	 $commentBody = $row['CommentBody'];
	 
     print "<strong>$commentHead</strong><br>";
	 print "$commentBody<br><br>";
  }
?>




</body>

</html>