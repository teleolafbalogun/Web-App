<!--Author(s): Canice/Keelan / Integration to Website: Keelan -->

<?php  

unset($_COOKIE['customerID']);


echo "<script>
					alert('Logged Out');
					window.location.href = 'index.php';
					</script>";

?>