<?php
// <!--Author(s): Floyd / Review Read PHP: Keelan -->
$mysqli=mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");


    if (mysqli_connect_errno())
    {
        printf("Connect failed: %s\n", mysqli_connect_error());
        exit();
    } else {
        $sql = "SELECT * from car WHERE CarModel = 'Continental GT'";
		$res = mysqli_query($mysqli,$sql);
		$row = mysqli_fetch_assoc( $res);
		
		$carName = $row['CarModel'];
		$year = $row['CarYear'];
		$price = $row['CarPrice'];
		$colour = $row['CarColour'];
		$fuelCapacity = $row['fuelCapacity'];
		$fueltype = $row['fueltype'];
		$maxSpeed = $row['maxSpeed'];
		$maxPower = $row['maxPower'];
		$maxTorque = $row['maxTorque'];
		setcookie("ID","3", time()+3600,'/');
    }
	



?>





<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta name="author" content="Floyd Teleola Balogun">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Continetal GTC</title>
  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="css/car.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <style>
    /* Styles for the product details */
    .product {
      display: flex;
      flex-direction: row;
      justify-content: space-between;
      align-items: center;
      border: 1px solid #ddd;
      padding: 125px;
      margin-bottom: 10px;
    }

    .product img {
      max-width: 10000px;
      max-height: 10000px;
      margin-right: 500px;
    }

    .product h2 {
      margin: 0;
    }

    .product p {
      margin: 0;
      font-size: 24px;
      color: #666;
    }

    .product .price {
      font-weight: bold;
      font-size: 18px;
    }

  </style>
</head>

<body>
   <nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
	  <a href="#"><img src="../images/logo.png" alt="logo" style="width:85px;height:42px;padding-top: 7px;padding-right: 10px;"></a>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="../index.php">Models</a></li>
        <li><a href="../orders.php">Orders</a></li>
 
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="../logout.php"><span class="glyphicon glyphicon-user"></span> Log Out</a></li>
        <li><a href="../mycart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart</a></li>
      </ul>
    </div>
  </div>
</nav>
  <!-- Product details section -->
  
  <div class="product container-fluid">
    <img src="../images/continentalGT.png" alt="Product Image" style="width:auto;height:auto;" >
    <div class="details">
      <h2><?php echo $carName; ?></h2>
	  <p>Year: <?php echo $year; ?></p>
      <p>Colour: <?php echo $colour; ?></p>
      <p>Fuel Capacity: <?php echo $fuelCapacity; ?> Litres</p>
      <p>Fuel Type: <?php echo $fueltype; ?></p>
      <p>Max Speed: <?php echo $maxSpeed; ?>MPH</p>
      <p>Max Power: <?php echo $maxPower; ?>BHP</p>
      <p>Max Torque: <?php echo $maxTorque; ?>NM</p>

      <BR>
      <p class="price">Price: £ <?php echo $price;?></p>
    </div>
	<div class="row-lg-2 d-flex justify-content-center">
    <form action="../mycart.php" method="POST">
      <button type="submit" name="Add_To_Cart" class="btn btn-info">Add to cart</button>
	  <input type = "hidden" name = "Item_Name" value = "Continental GT">
      <input type = "hidden" name = "Price" value = "40000">
    </form>
	</div>
  </div>

 
<h3>Reviews</h3>
<div class="row-lg-2 d-flex justify-content-center">
    <form action="../model.html">
      <button type="submit" name="writeReview" class="btn btn-info">Write a Review</button>
	 
    </form>
	</div>

  <?php
        $sql = "SELECT * FROM review WHERE CarID = 3";
        $res = mysqli_query($mysqli, $sql);
        $num_messages = mysqli_num_rows( $res);
?>

<?php
	while( $row = mysqli_fetch_assoc( $res) ) {
	 $stars = $row['Stars'];
     $commentHead = $row['CommentHead'];
	 $commentBody = $row['CommentBody'];
	 
     print "<strong>$commentHead</strong><br>";
	 print "$commentBody<br><br>";
  }
?>




</body>

</html>