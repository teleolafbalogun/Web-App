<?php

// <!--Author(s): Keelan / Integration to Website: Keelan -->

$mysqli = mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");

if(mysqli_connect_errno()) {
	printf("Connect failed: %s\n",mysqli_connect_error());
	exit();
} else {
	$sql = "INSERT INTO review(Stars, CommentHead, CommentBody, CarID)VALUES('".$_POST["star"]."','".$_POST["reviewHead"]."','".$_POST["reviewBody"]."','".$_POST["carModel"]."')";
	$res = mysqli_query($mysqli,$sql);
	if($res === TRUE) {
			echo "<script>
         alert('Review Submitted');
        window.location.href='index.php';
        </script>";
	} else {
		printf("Could not insert record: %s\n",mysqli_error($mysqli));
	}
	mysqli_close($mysqli);
}
?>


