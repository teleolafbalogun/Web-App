<?php 

// <!--Author(s): Canice / Integration to Website: Keelan -->

session_start();

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
	$gender = $_POST['gender'];
	$dob = $_POST['dob'];
	$street = $_POST['street'];
	$city = $_POST['city'];
	$postcode = $_POST['postcode'];
	$phone = $_POST['phone'];
	$email = $_POST['email'];
	$uname = $_POST['uname'];
	$pass = $_POST['pass'];

    
    if(empty($fname)){
    	$echo = "First name is required";
	    
    } else if(empty($lname)){
    	$echo = "Last name is required";

    } else if(empty($gender)){
    	$echo = "Gender is required";
	    
    } else if(empty($dob)){
    	$echo = "Date of Birth is required";
	    
    } else if(empty($street)){
    	$echo = "Street is required";
	   
    } else if(empty($city)){
    	$echo = "City is required";
	   
    } else if(empty($postcode)){
    	$echo = "Postcode is required";
	   
    } else if(empty($phone)){
    	$echo = "Phone Number is required";
	
    } else if(empty($email)){
    	$echo = "Email is required";

	} else if(empty($uname)){
    	$echo = "Username is required";
	} else if(empty($pass)){
    	$echo = "Password is required";
    } else {
		
		$mysqli = mysqli_connect("car-database.cxlfgruhwwnq.us-east-1.rds.amazonaws.com", "Group8", "WebApps123!", "cardealership_web");
		$sql = "INSERT INTO customer(cFname,cLname,cGender,cDOB,cPhone,cEmail,cStreet,cCity,cPostcode)VALUES('$fname','$lname','$gender','$dob','$phone','$email','$street','$city','$postcode')";
        $res = mysqli_query($mysqli, $sql);
		
		$sql1 = "SELECT CustomerID FROM customer WHERE cEmail = '$email'";
        $res1 = mysqli_query($mysqli, $sql1);
		$row = mysqli_fetch_assoc( $res1);
		$customerID = $row['CustomerID'];
		
		$sql2 = "INSERT INTO user(username, password, CustomerID)VALUES('$uname','$pass','$customerID')";
		$res2 = mysqli_query($mysqli, $sql2);
		
		echo "<script>
					alert('Account Created');
					window.location.href = 'index.php';
					</script>";
	}


?>